<template>
  <div>
    <p>
      Email <a href="mailto: jaredmimms@gmail.com">jaredmimms@gmail.com</a> with
      title, content, tags, and contact information for offering a service to
      the homeless.
    </p>
  </div>
</template>